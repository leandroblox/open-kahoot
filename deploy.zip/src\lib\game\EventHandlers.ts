import { Server as SocketIOServer, Socket } from 'socket.io';
import type { 
  ServerToClientEvents, 
  ClientToServerEvents,
  Question,
  GameSettings,
  Game,
  SanitizedGame
} from '@/types/game';
import { GameManager } from './GameManager';
import { PlayerManager } from './PlayerManager';
import { QuestionManager } from './QuestionManager';
import { GameplayLoop } from './GameplayLoop';
import { sanitizeGame } from './security';

export class EventHandlers {
  constructor(
    private io: SocketIOServer<ClientToServerEvents, ServerToClientEvents>,
    private gameManager: GameManager,
    private playerManager: PlayerManager,
    private questionManager: QuestionManager,
    private gameplayLoop: GameplayLoop
  ) {}

  setupEventHandlers(): void {
    this.io.on('connection', (socket) => {
      // Removed console.log

      socket.on('createGame', (title, questions, settings, callback) => {
        // Removed console.log
        this.handleCreateGame(socket, title, questions, settings, callback);
      });

      socket.on('joinGame', (pin, playerName, persistentId, callback) => {
        this.handleJoinGame(socket, pin, playerName, persistentId, callback);
      });

      socket.on('validateGame', (gameId, callback) => {
        this.handleValidateGame(socket, gameId, callback);
      });

      socket.on('startGame', (gameId) => {
        this.handleStartGame(socket, gameId);
      });

      socket.on('submitAnswer', (gameId, questionId, answerIndices, persistentId) => {
        this.handleSubmitAnswer(socket, gameId, questionId, answerIndices, persistentId);
      });

      socket.on('nextQuestion', (gameId) => {
        this.handleNextQuestion(socket, gameId);
      });

      socket.on('showLeaderboard', (gameId) => {
        this.handleShowLeaderboard(socket, gameId);
      });

      socket.on('endGame', (gameId) => {
        this.handleEndGame(socket, gameId);
      });

      socket.on('downloadGameLogs', (gameId) => {
        this.handleDownloadGameLogs(socket, gameId);
      });

      socket.on('toggleDyslexiaSupport', (gameId, playerId) => {
        this.handleToggleDyslexiaSupport(socket, gameId, playerId);
      });

      socket.on('disconnect', () => {
        this.handleDisconnect(socket);
      });
    });
  }

  private handleCreateGame(
    socket: Socket,
    title: string,
    questions: Question[],
    settings: GameSettings,
    callback: (game: Game) => void
  ): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.createGame(socket.id, title, questions, settings);
      socket.join(game.id);
      // Removed console.log
      callback(game);
    } catch (error) {
      console.error(`❌ [CREATE_GAME] Error creating game:`, error);
      socket.emit('error', 'Não foi possível criar o jogo');
    }
  }

  private handleJoinGame(
    socket: Socket,
    pin: string,
    playerName: string,
    persistentId?: string | ((success: boolean, game?: Game | SanitizedGame, playerId?: string) => void),
    callback?: (success: boolean, game?: Game | SanitizedGame, playerId?: string) => void
  ): void {
    // Handle both old and new callback signatures
    const actualCallback = typeof persistentId === 'function' ? persistentId : callback;
    const actualPersistentId = typeof persistentId === 'string' ? persistentId : null;
    
    // Removed console.log
    
    try {
      const game = this.gameManager.getGameByPin(pin);
      if (!game) {
        // Removed console.log
        actualCallback?.(false);
        return;
      }

      const result = this.playerManager.joinGame(game, socket.id, playerName, actualPersistentId);
      
      if (result.success && result.game) {
        socket.join(result.game.id);
        const connectedPlayers = this.playerManager.getConnectedPlayers(result.game).length;
        console.log(`[PIN ${result.game.pin}] Player joined/reconnected | Connected players: ${connectedPlayers}`);
        
        const player = this.playerManager.getPlayerById(result.playerId!, result.game);
        if (result.isReconnection) {
          this.io.to(result.game.id).emit('playerReconnected', player!);
        } else {
          this.io.to(result.game.id).emit('playerJoined', player!);
        }
      } else {
        // Removed console.log
      }
      
      actualCallback?.(result.success, result.game, result.playerId);
    } catch (error) {
      console.error(`❌ [JOIN_GAME] Error joining game:`, error);
      actualCallback?.(false);
    }
  }

  private handleValidateGame(
    socket: Socket,
    gameId: string,
    callback: (valid: boolean, game?: Game | SanitizedGame) => void
  ): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      const host = game ? this.playerManager.getHost(game) : undefined;
      const hasActiveHost = host?.isConnected ?? false;
      const isValid = !!game && hasActiveHost;
      
      // Removed console.log
      
      if (isValid) {
        socket.join(game.id);
        // Removed console.log
        
        // Check if this is a host or player
        const isHost = host && host.socketId === socket.id;
        
        // Sync to current game phase if game loop is active
        if (game.gameLoopActive) {
          this.gameplayLoop.syncPlayerToCurrentPhase(game, socket.id, !!isHost);
        }
        
        // Sanitize game data if not host
        const gameData = isHost ? game : sanitizeGame(game);
        
        callback(true, gameData);
      } else {
        callback(false);
      }
    } catch (error) {
      console.error(`❌ [VALIDATE_GAME] Error validating game:`, error);
      callback(false);
    }
  }

  private handleStartGame(socket: Socket, gameId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        socket.emit('error', 'Jogo não encontrado');
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        socket.emit('error', 'Não autorizado');
        return;
      }

      // Ensure host socket is in the game room
      socket.join(game.id);
      // Removed console.log

      const playerCount = this.playerManager.getConnectedPlayers(game).length;
      console.log(`[PIN ${game.pin}] Starting game with ${playerCount} active players`);
      
      // Start the gameplay loop
      // Send sanitized game to all (players don't need answers, host has them anyway)
      // Actually host needs them, but host is usually separate. 
      // Ideally we emit sanitized to room, and full to host.
      // But for simplicity, we emit sanitized to room. Host usually has local state or we can emit specific host event.
      // HOWEVER, the 'gameStarted' event is listened by everyone.
      // If we send sanitized, host UI might break if it expects answers?
      // Host UI usually uses the QuestionManager or just displays the questions.
      // Safe bet: Emit sanitized to room. Host can fetch full game via other means or we accept host gets sanitized in this event.
      // Checking Host screens: Host usually knows the questions from creation.
      this.io.to(game.id).emit('gameStarted', sanitizeGame(game));
      this.gameplayLoop.startGameLoop(game);
    } catch (error) {
      console.error(`❌ [START_GAME] Error starting game:`, error);
      socket.emit('error', 'Não foi possível iniciar o jogo');
    }
  }

  private handleSubmitAnswer(
    socket: Socket,
    gameId: string,
    questionId: string,
    answerIndices: number[],
    persistentId?: string
  ): void {
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        return;
      }

      const player = persistentId 
        ? this.playerManager.getPlayerById(persistentId, game)
        : this.playerManager.getPlayerBySocketId(socket.id, game);

      // Removed console.log

      if (game.phase !== 'answering') {
        // Removed console.log
        return;
      }

      const success = this.playerManager.submitAnswer(game, persistentId || socket.id, answerIndices, !!persistentId);
      if (success && player) {
        this.io.to(game.id).emit('playerAnswered', player.id);
        
        // Notify gameplay loop that a player answered (might trigger early phase transition)
        this.gameplayLoop.onPlayerAnswered(game);
      }
    } catch (error) {
      console.error(`❌ [SUBMIT_ANSWER] Error submitting answer:`, error);
    }
  }

  private handleNextQuestion(socket: Socket, gameId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        return;
      }

      if (game.phase !== 'leaderboard') {
        // Removed console.log
        return;
      }

      // Removed console.log
      this.gameplayLoop.transitionToPhase(game, 'preparation');
    } catch (error) {
      console.error(`❌ [NEXT_QUESTION] Error moving to next question:`, error);
    }
  }

  private handleShowLeaderboard(socket: Socket, gameId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        return;
      }

      // Removed console.log
      this.gameplayLoop.transitionToPhase(game, 'leaderboard');
    } catch (error) {
      console.error(`❌ [SHOW_LEADERBOARD] Error showing leaderboard:`, error);
    }
  }

  private handleEndGame(socket: Socket, gameId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        return;
      }

      // Removed console.log
      this.gameplayLoop.transitionToPhase(game, 'finished');
    } catch (error) {
      console.error(`❌ [END_GAME] Error ending game:`, error);
    }
  }

  private handleDownloadGameLogs(socket: Socket, gameId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        socket.emit('error', 'Jogo não encontrado');
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        socket.emit('error', 'Não autorizado');
        return;
      }

      // Generate the TSV logs
      const tsvData = this.playerManager.generateGameLogsTSV(game);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `game_${game.pin}_${timestamp}.tsv`;
      
      // Removed console.log
      socket.emit('gameLogs', tsvData, filename);
    } catch (error) {
      console.error(`❌ [DOWNLOAD_LOGS] Error generating logs:`, error);
      socket.emit('error', 'Não foi possível gerar os logs');
    }
  }

  private handleToggleDyslexiaSupport(socket: Socket, gameId: string, playerId: string): void {
    // Removed console.log
    
    try {
      const game = this.gameManager.getGame(gameId);
      if (!game) {
        // Removed console.log
        socket.emit('error', 'Jogo não encontrado');
        return;
      }

      if (!this.playerManager.isHost(socket.id, game)) {
        // Removed console.log
        socket.emit('error', 'Não autorizado');
        return;
      }

      // Only allow toggling in waiting phase
      if (game.status !== 'waiting') {
        // Removed console.log
        socket.emit('error', 'O suporte para dislexia só pode ser alterado no lobby');
        return;
      }

      const success = this.playerManager.toggleDyslexiaSupport(game, playerId);
      if (success) {
        const player = this.playerManager.getPlayerById(playerId, game);
        console.log(`[PIN ${game.pin}] Toggled dyslexia support for player ${player?.name || playerId} | New status: ${player?.hasDyslexiaSupport ? 'enabled' : 'disabled'}`);
        // Broadcast updated game state to all players in the room
        this.io.to(game.id).emit('gameUpdated', game);
      } else {
        // Removed console.log
        socket.emit('error', 'Não foi possível alternar o suporte para dislexia');
      }
    } catch (error) {
      console.error(`❌ [TOGGLE_DYSLEXIA] Error toggling dyslexia support:`, error);
      socket.emit('error', 'Não foi possível alternar o suporte para dislexia');
    }
  }

  private handleDisconnect(socket: Socket): void {
    // Removed console.log
    
    try {
      // Find which game this socket was part of
      for (const game of this.gameManager.getAllGames()) {
        const player = this.playerManager.getPlayerBySocketId(socket.id, game);
        if (player) {
          this.playerManager.disconnectPlayer(socket.id, game);
          this.io.to(game.id).emit('playerDisconnected', player.id);
          
          if (player.isHost) {
            // Removed console.log
            this.gameplayLoop.transitionToPhase(game, 'finished');
          } else {
            // Removed console.log
            // Note: We could implement reconnection logic here if needed
          }
          break;
        }
      }
    } catch (error) {
      console.error(`❌ [DISCONNECT] Error handling disconnect:`, error);
    }
  }
} 