'use client';

import GameFallbackScreen from '@/components/game-screens/GameFallbackScreen';

export default function DebugGameFallbackPage() {
  return (
    <GameFallbackScreen />
  );
} 