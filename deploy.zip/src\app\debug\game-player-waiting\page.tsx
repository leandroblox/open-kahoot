'use client';

import PlayerWaitingScreen from '@/components/player-screens/PlayerWaitingScreen';

export default function DebugGamePlayerWaitingPage() {
  return (
    <PlayerWaitingScreen />
  );
} 