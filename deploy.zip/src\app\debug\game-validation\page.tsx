'use client';

import GameValidationScreen from '@/components/game-screens/GameValidationScreen';

export default function DebugGameValidationPage() {
  return (
    <GameValidationScreen />
  );
} 