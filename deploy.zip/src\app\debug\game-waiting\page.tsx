'use client';

import GameWaitingScreen from '@/components/game-screens/GameWaitingScreen';

export default function DebugGameWaitingPage() {
  return (
    <GameWaitingScreen gameStatus="waiting" />
  );
} 